#ifndef PRACTICAL_SCHEDULER_SCHEDULER_H
#define PRACTICAL_SCHEDULER_SCHEDULER_H
#include "quantum.h"
#include <vector>

int greedy_scheduler(std::vector<quantum_program>& programs);

#endif //PRACTICAL_SCHEDULER_SCHEDULER_H