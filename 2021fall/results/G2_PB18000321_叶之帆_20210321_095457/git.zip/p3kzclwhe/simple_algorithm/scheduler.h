#ifndef PARA_SCHEDULER_SCHEDULER_H
#define PARA_SCHEDULER_SCHEDULER_H
#include "quantum.h"
#include <vector>

int greedy_scheduler(std::vector<quantum_program>& programs);

#endif //PARA_SCHEDULER_SCHEDULER_H