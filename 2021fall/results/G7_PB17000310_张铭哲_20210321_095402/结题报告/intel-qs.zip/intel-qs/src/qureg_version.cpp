#include "../include/qureg_version.hpp"

std::string GetQhipsterVersion( ) {
    return QHIPSTER_VERSION_STRING;
}
