The tests in this directory are for very basic language things that
we wanted to verify, such as arithmetic overflow and implicit casting.
